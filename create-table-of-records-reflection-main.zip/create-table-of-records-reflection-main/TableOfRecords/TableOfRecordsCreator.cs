using System.Reflection;

namespace TableOfRecords;

/// <summary>
/// Presents method that write in table form to the text stream a set of elements of type T.
/// </summary>
public static class TableOfRecordsCreator
{
    /// <summary>
    /// Write in table form to the text stream a set of elements of type T (<see cref="ICollection{T}"/>),
    /// where the state of each object of type T is described by public properties that have only built-in
    /// types (int, char, string, etc.).
    /// </summary>
    /// <typeparam name="T">Type selector.</typeparam>
    /// <param name="collection">Collection of elements of type T.</param>
    /// <param name="writer">Text stream.</param>
    /// <exception cref="ArgumentNullException">Thrown if <paramref name="collection"/> is null.</exception>
    /// <exception cref="ArgumentNullException">Thrown if <paramref name="writer"/> is null.</exception>
    /// <exception cref="ArgumentException">Thrown if <paramref name="collection"/> is empty.</exception>
    public static void WriteTable<T>(ICollection<T>? collection, TextWriter? writer)
    {
        ArgumentNullException.ThrowIfNull(collection);

        ArgumentNullException.ThrowIfNull(writer);

        if (collection.Count == 0)
        {
            throw new ArgumentException("The collection is empty.", nameof(collection));
        }

        PropertyInfo[] properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

        // Write table header
        foreach (PropertyInfo property in properties)
        {
            writer.Write($"{property.Name}\t");
        }

        writer.WriteLine();

        // Write table rows
        foreach (T item in collection)
        {
            foreach (PropertyInfo property in properties)
            {
                object? value = property.GetValue(item);
                writer.Write($"{value}\t");
            }

            writer.WriteLine();
        }
    }
}
