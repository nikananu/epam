﻿namespace TableOfRecords.Tests.UserProfiles
{
    public enum Gender
    {
        Male,
        Female,
    }
}
